// 🎮 Optimized Wii Controller by using Xbox Controller WebSocket Bridge for simulation
// Maintains identical functionality with reduced latency and GC pressure.

const ViGEmClient = require("vigemclient");
const WebSocket = require("ws");
const os = require("os");

// 🔍 Automatically detect local IPv4 address (LAN)
function getLocalIP() {
  const nets = os.networkInterfaces();
  const validInterfaces = [];

  // Get the IP address of the PC
  for (const [name, addrs] of Object.entries(nets)) {
    for (const net of addrs) {
      if (
        net.family === "IPv4" &&
        !net.internal &&
        !/vmware|virtualbox|hyper|loopback|vbox|docker|tunneling|bluetooth/i.test(
          name
        )
      ) {
        validInterfaces.push({ name, address: net.address });
      }
    }
  }

  // Prefer Wi-Fi or Host
  const preferred = validInterfaces.find(({ name }) =>
    /wi-?fi|lan/i.test(name)
  );

  return (preferred || validInterfaces[0] || { address: "127.0.0.1" }).address;
}

const localIP = getLocalIP();

// 🔌 Initialize ViGEm and controller
const client = new ViGEmClient();
client.connect();

const controller = client.createX360Controller();
controller.connect();

console.log("✅ Virtual Nintendo Wii (Simulated) controller connected.");

// 🌐 WebSocket server setup
const wss = new WebSocket.Server({ port: 8080 });
console.log(`🌐 WebSocket server running on ws://${localIP}:8080`);

// --- Prebind helper functions (avoids new closures inside onmessage) ---
const setButton = (btn, isDown, name) => {
  btn.setValue(isDown);
  console.log(`${name} ${isDown ? "pressed" : "released"}`);
};

const setAxis = (axis, value, name) => {
  axis.setValue(value);
  console.log(`${name} ${value !== 0 ? "pressed" : "released"}`);
};

// --- Predefine D-Pad and Analog constants for speed ---
const MAX = 32767;
const MIN = -32768;

// --- Predefine handlers map (no long if-else chain) ---
const handlers = {
  // 🎮 Left Analog
  leftAnalog: (data) => {
    controller.axis.leftX.setValue(data.leftAnalogX);
    controller.axis.leftY.setValue(-data.leftAnalogY);
    console.log(
      `🎮 Left Analog move: X=${data.leftAnalogX.toFixed(
        3
      )}, Y=${-data.leftAnalogY.toFixed(3)}`
    );
  },

  // 🎮 Right Analog
  rightAnalog: (data) => {
    controller.axis.rightX.setValue(data.rightAnalogX);
    controller.axis.rightY.setValue(-data.rightAnalogY);
    console.log(
      `🎮 Right analog move: X=${data.rightAnalogX.toFixed(
        3
      )}, Y=${-data.rightAnalogY.toFixed(3)}`
    );
  },

  // 🟢 A Button
  A: (isDown) => setButton(controller.button.A, isDown, "🟢 A button"),
  // 🔵 X Button
  1: (isDown) => setButton(controller.button.X, isDown, "🔵 X button"),
  // 🔴 B Button
  B: (isDown) => setButton(controller.button.B, isDown, "🔴 B button"),
  // 🟡 Y Button
  2: (isDown) => setButton(controller.button.Y, isDown, "🟡 Y button"),

  // Shoulder and Trigger Buttons
  LT: (isDown) => setAxis(controller.axis.leftTrigger, isDown, "LT button"),
  RT: (isDown) => setAxis(controller.axis.rightTrigger, isDown, "RT button"),
  Z: (isDown) =>
    setButton(controller.button.LEFT_SHOULDER, isDown, "LB button"),
  C: (isDown) =>
    setButton(controller.button.RIGHT_SHOULDER, isDown, "RB button"),

  // START, BACK and GUIDE Buttons
  "+": (isDown) => setButton(controller.button.START, isDown, "START button"),
  "-": (isDown) => setButton(controller.button.BACK, isDown, "BACK button"),
  HOME: (isDown) => setButton(controller.button.GUIDE, isDown, "GUIDE button"),
  POWER: (isDown) => setButton(controller.button.GUIDE, isDown, "GUIDE button"),

  // R3 and L3 Button
  R3: (isDown) => setButton(controller.button.RIGHT_THUMB, isDown, "R3 button"),
  L3: (isDown) => setButton(controller.button.LEFT_THUMB, isDown, "L3 button"),

  // D-Pad
  ARROW_UP: (isDown) =>
    setAxis(controller.axis.dpadVert, isDown ? MAX : 0, "⬆️ D-Pad UP"),
  ARROW_DOWN: (isDown) =>
    setAxis(controller.axis.dpadVert, isDown ? MIN : 0, "⬇️ D-Pad DOWN"),
  ARROW_LEFT: (isDown) =>
    setAxis(controller.axis.dpadHorz, isDown ? MIN : 0, "⬅️ D-Pad LEFT"),
  ARROW_RIGHT: (isDown) =>
    setAxis(controller.axis.dpadHorz, isDown ? MAX : 0, "➡️ D-Pad RIGHT"),
};

// --- Connection handling ---
wss.on("connection", (ws, req) => {
  const params = new URLSearchParams(req.url.split("?")[1]);
  const key = params.get("key");

  if (key !== "NINTENDO WII") {
    console.log("❌ Unauthorized connection attempt");
    ws.close(4001, "Invalid key");
    return;
  }

  console.log("✅ Authorized connection");
  console.log("📱 Android connected from:", req.socket.remoteAddress);

  ws.on("close", () => console.log("❌ Controller disconnected"));
  ws.on("error", (err) => console.error("⚠️ WebSocket error:", err.message));

  // ⚡ Efficient message handler
  ws.on("message", (msg) => {
    let data;
    try {
      data = JSON.parse(msg);
    } catch {
      console.warn("⚠️ Invalid JSON message, ignored.");
      return;
    }

    // Handle analog movement (fast path)
    if (data.leftAnalogX !== undefined && data.leftAnalogY !== undefined)
      return handlers.leftAnalog(data);
    if (data.rightAnalogX !== undefined && data.rightAnalogY !== undefined)
      return handlers.rightAnalog(data);

    // Handle buttons (mapped lookup)
    const button = data.button;
    if (button && handlers[button]) {
      const isDown = data.state === "down";
      handlers[button](isDown);
    }
  });
});

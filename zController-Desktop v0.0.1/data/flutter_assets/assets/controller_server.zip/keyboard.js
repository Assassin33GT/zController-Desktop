const WebSocket = require("ws");
const os = require("os");
const { keyboard, Key } = require("@nut-tree-fork/nut-js");

// 🔍 Detect local IPv4 address
function getLocalIP() {
  const nets = os.networkInterfaces();
  const validInterfaces = [];

  for (const [name, addrs] of Object.entries(nets)) {
    for (const net of addrs) {
      if (
        net.family === "IPv4" &&
        !net.internal &&
        !/vmware|virtualbox|hyper|loopback|vbox|docker|tunneling|bluetooth/i.test(
          name
        )
      ) {
        validInterfaces.push({ name, address: net.address });
      }
    }
  }

  const preferred = validInterfaces.find(({ name }) =>
    /wi-?fi|lan/i.test(name)
  );
  return (preferred || validInterfaces[0] || { address: "127.0.0.1" }).address;
}

const localIP = getLocalIP();
console.log("✅ Virtual Keyboard connected.");
console.log(`🌐 WebSocket server running on ws://${localIP}:8080`);

// 🌐 WebSocket server
const wss = new WebSocket.Server({ port: 8080 });

const specialKeys = {
  "{": "LeftBracket",
  "}": "RightBracket",
  ":": "Semicolon",
  DoubleQuote: "Quote",
  "<": "Comma",
  ">": "Decimal",
  "?": "Slash",
  _: "Minus",
  "|": "Backslash",
  "~": "Grave",
};

wss.on("connection", (ws, req) => {
  const params = new URLSearchParams(req.url.split("?")[1]);
  const key = params.get("key");

  if (key !== "KEYBOARD") {
    console.log("❌ Unauthorized connection attempt");
    ws.close(4001, "Invalid key");
    return;
  }

  console.log("📱 Android connected.");

  ws.on("message", async (msg) => {
    try {
      const data = JSON.parse(msg);
      if (!data.key || !data.state) return;

      let originalKey = data.key;
      const keyName = originalKey.toUpperCase(); // Convert to uppercase for nut-js constants
      const isLetter = /^[A-Z]$/.test(keyName);
      const isUppercase = originalKey === keyName && isLetter;

      if (!Key[keyName] && !Key[originalKey] && !specialKeys[originalKey]) {
        console.warn(`⚠️ Unknown key: ${originalKey}`);
        return;
      }

      if (data.state === "down") {
        if (isLetter) {
          if (isUppercase) await keyboard.pressKey(Key.LeftShift);
          await keyboard.pressKey(Key[keyName]);
        } else {
          if (specialKeys[originalKey]) {
            originalKey = specialKeys[originalKey];
            await keyboard.pressKey(Key.LeftShift);
          }
          await keyboard.pressKey(Key[originalKey]);
        }
        console.log(`⬇️ Pressed ${originalKey}`);
      } else if (data.state === "up") {
        if (isLetter) {
          await keyboard.releaseKey(Key[keyName]);
          if (isUppercase) await keyboard.releaseKey(Key.LeftShift);
        } else {
          await keyboard.releaseKey(Key[originalKey]);
          if (specialKeys[originalKey])
            await keyboard.releaseKey(Key.LeftShift);
        }
        console.log(`⬆️ Released ${originalKey}`);
      }
    } catch (e) {
      console.error("⚠️ Invalid message:", e);
    }
  });

  ws.on("close", () => console.log("❌ Android disconnected."));
});

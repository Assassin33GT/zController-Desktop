const WebSocket = require("ws");
const os = require("os");
const { keyboard, Key } = require("@nut-tree-fork/nut-js");

// 🔍 Automatically detect local IPv4 address (LAN)
function getLocalIP() {
  const nets = os.networkInterfaces();
  const validInterfaces = [];

  for (const [name, addrs] of Object.entries(nets)) {
    for (const net of addrs) {
      if (
        net.family === "IPv4" &&
        !net.internal &&
        !/vmware|virtualbox|hyper|loopback|vbox|docker|tunneling|bluetooth/i.test(
          name
        )
      ) {
        validInterfaces.push({ name, address: net.address });
      }
    }
  }

  const preferred = validInterfaces.find(({ name }) =>
    /wi-?fi|lan/i.test(name)
  );
  return (preferred || validInterfaces[0] || { address: "127.0.0.1" }).address;
}

const localIP = getLocalIP();
console.log("✅ Steering Wheel connected.");
console.log(`🌐 WebSocket server running on ws://${localIP}:8080`);

// 🌐 WebSocket server
const wss = new WebSocket.Server({ port: 8080 });

wss.on("connection", (ws, req) => {
  const params = new URLSearchParams(req.url.split("?")[1]);
  const key = params.get("key");

  if (key !== "STEERING WHEEL") {
    console.log("❌ Unauthorized connection attempt");
    ws.close(4001, "Invalid key");
    return;
  }

  console.log("📱 Android connected from:", req.socket.remoteAddress);

  ws.on("message", async (msg) => {
    try {
      const data = JSON.parse(msg);

      if (!data.key || !data.state) return;

      // Normalize key (A → Key.A, D → Key.D, etc.)
      const keyName = data.key;

      if (!Key[keyName]) {
        console.warn(`⚠️ Unknown key: ${keyName}`);
        return;
      }

      if (data.state === "down") {
        await keyboard.pressKey(Key[keyName]);
        console.log(`⬇️ Pressed ${keyName}`);
      } else if (data.state === "up") {
        await keyboard.releaseKey(Key[keyName]);
        console.log(`⬆️ Released ${keyName}`);
      }
    } catch (e) {
      console.error("⚠️ Invalid message:", e);
    }
  });

  ws.on("close", () => {
    console.log("❌ Android disconnected.");
  });
  ws.on("error", (err) => console.error("⚠️ WebSocket error:", err.message));
});

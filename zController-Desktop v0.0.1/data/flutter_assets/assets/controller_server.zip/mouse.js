const WebSocket = require("ws");
const os = require("os");
const { mouse, Point, Button, linear } = require("@nut-tree-fork/nut-js");

// 🟦 NutJS settings
mouse.config.mouseSpeed = 0; // We manually control speed
mouse.config.interpolation = linear; // Smooth linear motion

// 📌 Smooth trackpad-style movement
async function smoothMove(deltaX, deltaY, steps = 6) {
  const start = await mouse.getPosition();
  const stepX = deltaX / steps;
  const stepY = deltaY / steps;

  for (let i = 0; i < steps; i++) {
    const nextX = start.x + stepX * (i + 1);
    const nextY = start.y + stepY * (i + 1);
    await mouse.setPosition(new Point(nextX, nextY));
  }
}

// 🔍 Detect local IPv4 address
function getLocalIP() {
  const nets = os.networkInterfaces();
  const validInterfaces = [];

  for (const [name, addrs] of Object.entries(nets)) {
    for (const net of addrs) {
      if (
        net.family === "IPv4" &&
        !net.internal &&
        !/vmware|virtualbox|hyper|loopback|vbox|docker|tunneling|bluetooth/i.test(
          name
        )
      ) {
        validInterfaces.push({ name, address: net.address });
      }
    }
  }

  const preferred = validInterfaces.find(({ name }) =>
    /wi-?fi|lan/i.test(name)
  );
  return (preferred || validInterfaces[0] || { address: "127.0.0.1" }).address;
}

const localIP = getLocalIP();
console.log("✅ Virtual Keyboard connected.");
console.log(`🌐 WebSocket server running on ws://${localIP}:8080`);

// 🌐 WebSocket server
const wss = new WebSocket.Server({ port: 8080 });

wss.on("connection", (ws, req) => {
  const params = new URLSearchParams(req.url.split("?")[1]);
  const key = params.get("key");

  if (key !== "MOUSE") {
    console.log("❌ Unauthorized connection attempt");
    ws.close(4001, "Invalid key");
    return;
  }

  console.log("📱 Android connected.");

  ws.on("message", async (msg) => {
    try {
      const data = JSON.parse(msg);

      // Handle Mouse Move
      if (typeof data.X === "number" && typeof data.Y === "number") {
        await smoothMove(data.X, data.Y, 6); // 6 steps = super smooth
        return;
      }

      // Mouse Buttons
      if (!data.key || !data.state) return;

      const key = data.key;
      const state = data.state;

      // Mouse click handling
      if (key === "Left Click") {
        await mouse.leftClick();
      } else if (key === "Right Click") {
        if (state === "down") {
          await mouse.pressButton(Button.RIGHT);
        } else if (state === "up") {
          await mouse.releaseButton(Button.RIGHT);
        }
      } else if (key === "Middle Click") {
        if (state === "down") {
          await mouse.pressButton(Button.MIDDLE);
        } else if (state === "up") {
          await mouse.releaseButton(Button.MIDDLE);
        }
      } else if (key === "Scroll Down") {
        if (state === "down") {
          await mouse.scrollDown(120);
        }
      } else if (key === "Scroll Up") {
        if (state === "down") {
          await mouse.scrollUp(120);
        }
      }

      console.log(`${state === "down" ? "⬇️ Pressed" : "⬆️ Released"} ${key}`);
    } catch (e) {
      console.error("⚠️ Invalid message:", e);
    }
  });

  ws.on("close", () => console.log("❌ Android disconnected."));
});
